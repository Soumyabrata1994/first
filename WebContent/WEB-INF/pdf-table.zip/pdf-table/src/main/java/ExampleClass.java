import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;

import pdftable.PdfTableReader;
import pdftable.models.ParsedTablePage;
import pdftable.models.ParsedTablePage.ParsedTableRow;

public class ExampleClass {

	public static void main(String args[]) throws IOException{
		//PDDocument pdfDoc = PDDocument.load(new File("D:\\Sid\\PDFExtractor\\INT007714_TIP0718068163_New.pdf"));
		PDDocument pdfDoc = PDDocument.load(new File("D:\\Sid\\PDFReader\\NPL056081_271803G10164990_New.pdf"));
		PdfTableReader reader = new PdfTableReader();

		// first page in document has index == 1, not 0 !
		ParsedTablePage firstPage = reader.parsePdfTablePage(pdfDoc, 3);

		// getting page number
		assert firstPage.getPageNum() == 3;

		// rows and cells are zero-indexed just like elements of the List
		// getting first row
		System.out.println(firstPage.getRows().size());
		
		List<ParsedTableRow> parsedTableRow = firstPage.getRows();
		int count=0;
		for(ParsedTableRow p : parsedTableRow){
			for(int i=0 ; i < p.getCells().size() ; i++){
				System.out.print("["+p.getCell(i)+"]");
			}
			System.out.println();
			System.out.println("===========================================================");
			
			}
		
		ParsedTablePage.ParsedTableRow firstRow = firstPage.getRow(0);

		// getting third cell in second row
		String thirdCellContent = firstPage.getRow(0).getCell(0);
		System.out.println(thirdCellContent);
		// cell content usually contain <CR><LF> characters,
		// so it is recommended to trim them before processing
		//double thirdCellNumericValue = Double.valueOf(thirdCellContent.trim());
	}
}
