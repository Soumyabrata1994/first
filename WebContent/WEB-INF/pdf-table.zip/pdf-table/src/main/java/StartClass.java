import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.testng.TestException;

import pdftable.PdfTableReader;
import pdftable.models.ParsedTablePage;

public class StartClass {
    private static final Path TEST_OUT_PATH = Paths.get("C:", "pdf_tests");
    private static final String TEST_FILENAME = "D:\\dump\\test_tables.pdf";
    //private static final String TEST_FILENAME = "D:\\Sid\\PDFExtractor\\INT007714_TIP0718068163_New.pdf";
    private static PDDocument PDFdoc;
    private static final int THREAD_COUNT = 8;
    private static final int PAGE_CYCLE = 4;
	public static void main(String[] args) throws IOException{
		//LoadLibrary.loadOpenCV();
		System.out.println(System.getProperty("java.library.path"));
	        long start = System.currentTimeMillis();
	        PdfTableReader reader = new PdfTableReader();
	        ExecutorService executor = Executors.newFixedThreadPool(THREAD_COUNT);
	        PDFdoc = getTestPDF();
	        List<Future<ParsedTablePage>> futures = new ArrayList<>();
	        for (final int pageNum : IntStream.rangeClosed(1, PDFdoc.getNumberOfPages()).toArray()) {
	            Callable<ParsedTablePage> callable = () -> {
	                ParsedTablePage page = reader.parsePdfTablePage(PDFdoc, pageNum);
	                return page;
	            };
	            futures.add(executor.submit(callable));
	        }

	        List<ParsedTablePage> parsedPages = new ArrayList<>(PDFdoc.getNumberOfPages());
	        try {
	            for (Future<ParsedTablePage> f : futures) {
	                ParsedTablePage page = f.get();
	                parsedPages.add(page.getPageNum() - 1, page);
	            }
	        } catch (Exception e) {
	            e.printStackTrace();
	        	//throw new TestException(e);
	        }
	        finally{
	        	 if (PDFdoc != null) {
	                 try {
	                     PDFdoc.close();
	                 } catch (IOException e) {
	                	 e.printStackTrace();
	                 }
	             }
	        }
	        long end = System.currentTimeMillis();
	        System.out.println("parse pages - multi thread: " + (end - start) / 1000.0);

	        List<ParsedTablePage> sortedParsedPages = parsedPages.stream()
	                .sorted((p1, p2) -> Integer.compare(p1.getPageNum(), p2.getPageNum())).collect(Collectors.toList());
	        
	        for(int i= 0 ; i<2 ; i++){
	        	//for(int j=0;j<2;j++){
	        //for (int i : IntStream.iterate(0, x -> x + PAGE_CYCLE).limit(1).toArray()) {
	        	System.out.println("Print Pages-->>"+normalizeWhitespaces(sortedParsedPages.get(2).getRow(2).getCell(0)));
	         //}
	        }
	        if (PDFdoc != null) {
	            try {
	                PDFdoc.close();
	            } catch (IOException e) {
	            	e.printStackTrace();
	            }
	        }

	    }
	public static PDDocument getTestPDF() {
        try {
            //ClassLoader classLoader = getClass().getClassLoader();
            File file = new File(TEST_FILENAME);
            return PDDocument.load(file);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
            //throw new RuntimeException(e.getCause());
        }
    }
	 private static String normalizeWhitespaces(String input) {
	        return input.replaceAll("[\\s\\u00A0]+", " ").trim();
	    }
	}

